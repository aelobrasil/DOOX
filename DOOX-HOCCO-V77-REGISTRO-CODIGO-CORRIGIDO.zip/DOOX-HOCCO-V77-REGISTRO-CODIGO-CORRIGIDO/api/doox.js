import postgres from 'postgres';
import crypto from 'node:crypto';

const RAW_DATABASE_URL = String(process.env.DOOX_DATABASE_URL || '').trim();
let db = null;
let dbConfigError = '';
if (RAW_DATABASE_URL) {
  if (!/^postgres(?:ql)?:\/\//i.test(RAW_DATABASE_URL)) {
    dbConfigError = 'DOOX_DATABASE_URL inválida: use a conexão PostgreSQL/Transaction Pooler do Supabase, não a URL https://...supabase.co.';
  } else {
    try {
      db = postgres(RAW_DATABASE_URL, {
        ssl: 'require',
        prepare: false,
        max: 1,
        idle_timeout: 20,
        connect_timeout: 10,
      });
    } catch (error) {
      dbConfigError = 'DOOX_DATABASE_URL inválida. Confira a string PostgreSQL do Supabase.';
    }
  }
}

const MODE_MAP = {
  'Presença no Rodapé': 'RODAPE',
  'Sponsor Overlay': 'SPONSOR_OVERLAY',
  'Overlay + Áudio': 'OVERLAY_AUDIO',
  'Empresa Patrocinadora do Episódio': 'PATROCINADOR_EPISODIO',
  'Apoiador Individual': 'APOIADOR_INDIVIDUAL',
};

const RANGE_MAP = {
  '00:30–02:00': 'F1',
  '02:00–04:00': 'F2',
  '04:00–06:30': 'F3',
  '06:30–09:00': 'F4',
  '09:00–11:00': 'F5',
};

const STATUS_LABELS = {
  SOLICITADO: 'SOLICITADO',
  EM_ANALISE: 'EM ANÁLISE',
  APROVADO: 'APROVADO',
  FILA_DE_ESPERA: 'FILA DE ESPERA',
  EM_PRODUCAO: 'EM PRODUÇÃO',
  PROGRAMADO: 'PROGRAMADO',
  VEICULADO: 'PUBLICADO',
  FINALIZADO: 'FINALIZADO',
  CANCELADO: 'CANCELADO',
};

const STATUS_PROGRESS = {
  SOLICITADO: 10,
  EM_ANALISE: 20,
  APROVADO: 42,
  FILA_DE_ESPERA: 48,
  EM_PRODUCAO: 78,
  PROGRAMADO: 88,
  VEICULADO: 96,
  FINALIZADO: 100,
  CANCELADO: 100,
};

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.end(JSON.stringify(body));
}

function normalizeBody(req) {
  if (!req.body) return {};
  if (typeof req.body === 'object') return req.body;
  try { return JSON.parse(req.body); } catch { return {}; }
}

function getAction(req, url, body) {
  return String(
    url.searchParams.get('action') || body.action || 'health'
  ).trim();
}

function requireDb(res) {
  if (dbConfigError) {
    console.error('DOOX database configuration:', dbConfigError);
    json(res, 503, { ok: false, code: 'SERVICE_UNAVAILABLE', message: 'Serviço temporariamente indisponível.' });
    return false;
  }
  if (!db) {
    console.error('DOOX database configuration: DOOX_DATABASE_URL ausente.');
    json(res, 503, { ok: false, code: 'SERVICE_UNAVAILABLE', message: 'Serviço temporariamente indisponível.' });
    return false;
  }
  return true;
}

function parseCookies(req) {
  const raw = String(req.headers.cookie || '');
  return Object.fromEntries(raw.split(';').map(part => {
    const i = part.indexOf('=');
    if (i < 0) return ['', ''];
    return [part.slice(0, i).trim(), decodeURIComponent(part.slice(i + 1).trim())];
  }).filter(([k]) => k));
}

const DEFAULT_ADMIN_PASSWORD_HASH = 'scrypt$N=16384,r=8,p=1$6R2yxd0DTs7360wsZYo3xA$gyJHji-UBmYdT4_CkjQB3CwS0zg3O0WSiGDzfiBZM0U';

function getAdminPasswordHash() {
  return String(process.env.DOOX_ADMIN_PASSWORD_HASH || DEFAULT_ADMIN_PASSWORD_HASH);
}

function getAdminSessionSecret() {
  return String(process.env.DOOX_ADMIN_SECRET || process.env.DOOX_ADMIN_SESSION_SECRET || DEFAULT_ADMIN_PASSWORD_HASH);
}

function verifyAdminPassword(password) {
  try {
    const raw = String(password || '');
    const parts = getAdminPasswordHash().split('$');
    if (parts.length !== 4 || parts[0] !== 'scrypt') return false;
    const params = Object.fromEntries(parts[1].split(',').map(item => item.split('=')));
    const N = Number(params.N), r = Number(params.r), p = Number(params.p);
    if (![N, r, p].every(Number.isFinite)) return false;
    const salt = Buffer.from(parts[2], 'base64url');
    const expected = Buffer.from(parts[3], 'base64url');
    const derived = crypto.scryptSync(raw, salt, expected.length, { N, r, p, maxmem: 64 * 1024 * 1024 });
    return derived.length === expected.length && crypto.timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

function makeAdminSession() {
  const secret = getAdminSessionSecret();
  const ttlHours = Math.max(1, Number(process.env.DOOX_ADMIN_SESSION_HOURS || 12));
  const expires = Date.now() + ttlHours * 60 * 60 * 1000;
  const payload = `admin.${expires}`;
  const signature = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  return `${Buffer.from(payload).toString('base64url')}.${signature}`;
}

function verifyAdminSession(token) {
  const secret = getAdminSessionSecret();
  if (!token) return false;
  try {
    const [encoded, received] = String(token).split('.');
    if (!encoded || !received) return false;
    const payload = Buffer.from(encoded, 'base64url').toString('utf8');
    const expected = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
    const a = Buffer.from(received);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return false;
    const [kind, expiresRaw] = payload.split('.');
    return kind === 'admin' && Number.isFinite(Number(expiresRaw)) && Date.now() < Number(expiresRaw);
  } catch {
    return false;
  }
}

function requireAdmin(req, res) {
  const cookies = parseCookies(req);
  const sessionOk = verifyAdminSession(cookies.doox_admin_session);
  const legacyHeader = String(req.headers['x-doox-admin-secret'] || '');
  const legacyOk = Boolean(process.env.DOOX_ADMIN_SECRET && legacyHeader && legacyHeader === process.env.DOOX_ADMIN_SECRET);

  if (!sessionOk && !legacyOk) {
    json(res, 401, { ok: false, message: 'Autorização administrativa necessária.' });
    return false;
  }
  return true;
}

function adminLogin(req, res, body) {
  if (!verifyAdminPassword(body.password)) {
    return json(res, 401, { ok: false, message: 'Senha administrativa incorreta.' });
  }
  const session = makeAdminSession();
  const secure = String(req.headers['x-forwarded-proto'] || '').includes('https') || process.env.NODE_ENV === 'production';
  res.setHeader('Set-Cookie', `doox_admin_session=${encodeURIComponent(session)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.max(3600, Number(process.env.DOOX_ADMIN_SESSION_HOURS || 12) * 3600)}${secure ? '; Secure' : ''}`);
  return json(res, 200, { ok: true, authenticated: true });
}

function parsePositiveInt(value, fallback = 1) {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

function mapType(value) {
  const raw = String(value ?? '').trim();
  const normalized = raw
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[._\/-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (['empresa', 'empresas', 'pj', 'pessoa juridica', 'pessoa juridica empresa'].includes(normalized)) {
    return 'EMPRESA';
  }
  if (['pessoa', 'pessoa fisica', 'pessoa física', 'pf', 'individual', 'apoiador individual'].includes(normalized)) {
    return 'PESSOA_FISICA';
  }
  if (['empresa', 'pessoa_fisica', 'empresa'.toUpperCase(), 'PESSOA_FISICA'].includes(raw)) {
    return raw.toUpperCase();
  }
  return '';
}

function resolveParticipationType(body, modality) {
  const candidates = [
    body.type,
    body.tipo_participacao,
    body.tipoParticipacao,
    body.participationType,
    body.audience,
    body.público,
    body.publico,
    body.ptype,
  ];

  for (const candidate of candidates) {
    const mapped = mapType(candidate);
    if (mapped) return mapped;
  }

  // Fallback seguro: a modalidade Apoiador Individual é exclusiva de pessoa física;
  // as demais modalidades comerciais do catálogo são empresariais.
  if (modality === 'APOIADOR_INDIVIDUAL') return 'PESSOA_FISICA';
  return 'EMPRESA';
}

function mapModality(value) {
  if (MODE_MAP[value]) return MODE_MAP[value];
  const v = String(value || '').trim().toUpperCase();
  return Object.values(MODE_MAP).includes(v) ? v : v;
}

function mapRange(value) {
  if (!value) return null;
  if (RANGE_MAP[value]) return RANGE_MAP[value];
  const v = String(value).trim().toUpperCase();
  return /^F[1-5]$/.test(v) ? v : null;
}

function b64url(input) {
  return Buffer.from(input).toString('base64url');
}

function getTrackingSecret() {
  const explicit = String(
    process.env.DOOX_TRACKING_SECRET ||
    process.env.DOOX_ADMIN_SECRET ||
    process.env.DOOX_ADMIN_SESSION_SECRET ||
    ''
  ).trim();
  if (explicit) return explicit;
  // Compatibilidade segura: se o banco já está configurado, deriva uma chave HMAC
  // estável sem expor a credencial. Em produção, DOOX_TRACKING_SECRET continua recomendado.
  if (RAW_DATABASE_URL) {
    return crypto.createHash('sha256').update(`doox-tracking-v1:${RAW_DATABASE_URL}`).digest('hex');
  }
  throw new Error('Serviço de acompanhamento não configurado.');
}

function sign(value) {
  return crypto.createHmac('sha256', getTrackingSecret()).update(value).digest('base64url');
}

function makeTrackingToken(pedidoId) {
  const ttlDays = parsePositiveInt(process.env.DOOX_TRACKING_TTL_DAYS, 3650);
  const expires = Date.now() + ttlDays * 24 * 60 * 60 * 1000;
  const payload = `${pedidoId}.${expires}`;
  return `${b64url(payload)}.${sign(payload)}`;
}

function verifyTrackingToken(token) {
  if (!token || typeof token !== 'string') throw new Error('Token de acompanhamento inválido.');
  const [encoded, receivedSignature] = token.split('.');
  if (!encoded || !receivedSignature) throw new Error('Token de acompanhamento inválido.');
  const payload = Buffer.from(encoded, 'base64url').toString('utf8');
  const [pedidoId, expiresRaw] = payload.split('.');
  const expectedSignature = sign(payload);
  const a = Buffer.from(receivedSignature);
  const b = Buffer.from(expectedSignature);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    throw new Error('Token de acompanhamento inválido.');
  }
  const expires = Number(expiresRaw);
  if (!pedidoId || !Number.isFinite(expires) || Date.now() > expires) {
    throw new Error('Token de acompanhamento expirado.');
  }
  return pedidoId;
}

function modalityName(code) {
  return Object.entries(MODE_MAP).find(([, v]) => v === code)?.[0] || code;
}

function normalizeTracking(data, pedido) {
  const status = pedido?.status_operacional || pedido?.status || 'SOLICITADO';
  const pay = pedido?.pagamentos?.[0] || {};
  const materiais = pedido?.materiais || [];
  const allApproved = materiais.length === 0 || materiais.every(m => m.status === 'APROVADO');
  const discount = Number(pedido?.valor_desconto || 0);

  return {
    ok: true,
    code: pedido.codigo_doox,
    status,
    statusLabel: STATUS_LABELS[status] || status,
    progressPercent: STATUS_PROGRESS[status] ?? 10,
    updatedAt: pedido.atualizado_em || pedido.criado_em,
    discount,
    coupon: data?.coupon || '',
    customerMessage: data?.customerMessage || '',
    observationClient: data?.observationClient || '',
    payment: {
      available: false,
      status: pedido.status_pagamento,
      amountLabel: `Valor do pedido: R$ ${Number(pedido.valor_total || 0).toFixed(2).replace('.', ',')}`,
      pixPayload: '',
    },
    materials: materiais,
    materialReady: allApproved,
    receipt: {
      eligible: pedido.status_veiculacao === 'FINALIZADA' || pedido.status_operacional === 'FINALIZADO',
    },
  };
}

async function callJson(sqlQuery) {
  const rows = await sqlQuery;
  if (!rows?.length) throw new Error('O DOOX CORE não retornou dados.');
  const value = rows[0]?.data;
  if (value && typeof value === 'object' && value.ok === false) {
    throw new Error(value.message || 'Operação recusada pelo DOOX CORE.');
  }
  return value;
}

function firstObjectCandidates(value) {
  const out = [];
  const push = (v) => { if (v && typeof v === 'object' && !Array.isArray(v) && !out.includes(v)) out.push(v); };
  push(value);
  push(value?.pedido);
  push(value?.data);
  push(value?.resultado);
  push(value?.result);
  push(value?.solicitacao);
  push(value?.request);
  if (Array.isArray(value) && value.length) push(value[0]);
  return out;
}

function pickCreationIdentity(created) {
  let pedidoId = '';
  let code = '';
  if (typeof created === 'string') {
    const raw = created.trim();
    if (/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(raw)) pedidoId = raw;
    else if (raw) code = raw;
  }
  for (const item of firstObjectCandidates(created)) {
    pedidoId ||= String(item.pedido_id || item.pedidoId || item.id || item.uuid || '').trim();
    code ||= String(item.codigo_doox || item.codigoDoox || item.codigo || item.code || '').trim();
  }
  return { pedidoId, code };
}

async function registerRequest(body) {
  if (body.website) throw new Error('Solicitação recusada.');
  if (body.termsAccepted !== true || body.rulesAccepted !== true) {
    throw new Error('Os Termos de Uso e as Regras de Participação precisam ser aceitos.');
  }

  const modality = mapModality(body.modality || body.modalidade);
  const type = resolveParticipationType(body, modality);
  const range = mapRange(body.moment || body.faixa);
  const quantity = parsePositiveInt(body.quantity ?? body.quantidade, 1);
  const name = String(body.name || body.nome || '').trim();
  const company = String(body.company || body.empresa || '').trim();
  const email = String(body.email || '').trim().toLowerCase();
  const whatsapp = String(body.whatsapp || '').replace(/\D/g, '');

  if (!name || !email || !whatsapp) throw new Error('Nome, WhatsApp e E-mail são obrigatórios.');
  if (!['EMPRESA', 'PESSOA_FISICA'].includes(type)) throw new Error('Tipo de participação inválido.');
  if (!modality) throw new Error('Modalidade inválida.');
  if (['SPONSOR_OVERLAY', 'OVERLAY_AUDIO'].includes(modality) && !range) {
    throw new Error('Selecione o momento/faixa da participação.');
  }
  if (type === 'EMPRESA' && !company) throw new Error('Nome da empresa é obrigatório.');
  if (type === 'PESSOA_FISICA' && modality !== 'APOIADOR_INDIVIDUAL') {
    throw new Error('Pessoa física participa somente como Apoiador Individual.');
  }
  if (type === 'EMPRESA' && modality === 'APOIADOR_INDIVIDUAL') {
    throw new Error('Apoiador Individual é exclusivo para pessoa física.');
  }
  if (type === 'EMPRESA' && body.companyTermsAccepted !== true) {
    throw new Error('O Termo de Participação Empresarial precisa ser aceito.');
  }

  const idempotencyKey = String(
    body.clientRequestId || body.idempotency_key || crypto.randomUUID()
  ).trim();

  const benefit = Number(body.discount || 0) > 0
    ? {
        tipo: 'CONDICAO',
        codigo: String(body.coupon || '').trim() || null,
        descricao: String(body.benefit || '').trim() || `${Number(body.discount)}% de desconto para quem vier pela HOCCO`,
      }
    : null;

  const payload = {
    tipo_participacao: type,
    modalidade: modality,
    faixa: range,
    quantidade: quantity,
    nome: name,
    empresa: company || null,
    whatsapp,
    email,
    perfil: String(body.profile || body.perfil || '').trim() || null,
    segmento: String(body.segment || body.segmento || '').trim() || null,
    observacoes: String(body.observation || body.observacoes || '').trim() || null,
    momento_preferencial: range,
    idempotency_key: idempotencyKey,
    origem: 'SITE_1',
    beneficio: benefit,
  };

  // Contrato de criação preservado: criar_pedido(jsonb) recebe apenas os campos
  // operacionais originais. O aceite empresarial é registrado separadamente
  // depois que o pedido já possui UUID e Código DOOX.
  let created;
  try {
    created = await callJson(
      db`SELECT doox_core.criar_pedido(${JSON.stringify(payload)}::jsonb) AS data`
    );
  } catch (error) {
    error.publicStage = 'REGISTRO_PEDIDO';
    throw error;
  }

  let { pedidoId, code: createdCode } = pickCreationIdentity(created);

  // Algumas versões da função SQL devolvem o código, mas não o UUID no primeiro nível.
  // Recupera o mesmo registro já criado, sem gerar um segundo pedido.
  if (!pedidoId && createdCode) {
    try {
      const rows = await db`
        SELECT id, codigo_doox
        FROM doox_core.pedidos
        WHERE codigo_doox = ${createdCode}
        ORDER BY criado_em DESC
        LIMIT 1
      `;
      pedidoId = String(rows?.[0]?.id || '').trim();
      createdCode ||= String(rows?.[0]?.codigo_doox || '').trim();
    } catch (_) {}
  }

  // Fallback de idempotência: tenta localizar a solicitação que acabou de ser criada.
  if (!pedidoId) {
    try {
      const rows = await db`
        SELECT id, codigo_doox
        FROM doox_core.pedidos
        WHERE idempotency_key = ${idempotencyKey}
        ORDER BY criado_em DESC
        LIMIT 1
      `;
      pedidoId = String(rows?.[0]?.id || '').trim();
      createdCode ||= String(rows?.[0]?.codigo_doox || '').trim();
    } catch (_) {}
  }

  if (!pedidoId) throw new Error('A solicitação foi registrada sem identificador operacional.');

  let pedido = null;
  try {
    pedido = await callJson(db`SELECT doox_core.resumo_pedido(${pedidoId}::uuid) AS data`);
  } catch (_) {
    // Fallback direto: o registro principal é a fonte de verdade mesmo se a função de resumo
    // estiver temporariamente indisponível ou tiver assinatura diferente.
    try {
      const rows = await db`
        SELECT id, codigo_doox, modalidade, faixa_comercial AS faixa, quantidade, valor_unitario, valor_total,
               status_operacional, status_pagamento, criado_em, atualizado_em
        FROM doox_core.pedidos
        WHERE id = ${pedidoId}::uuid
        LIMIT 1
      `;
      pedido = rows?.[0] || null;
    } catch (_) {
      pedido = null;
    }
  }

  let acceptanceRegistered = type !== 'EMPRESA';
  if (type === 'EMPRESA') {
    try {
      await callJson(
        db`
          SELECT doox_core.registrar_aceite(
            ${pedidoId}::uuid,
            'TERMO_EMPRESA_ACEITE',
            ${String(body.companyTermsVersion || '1.0-2026-09-20')},
            ${name},
            ${`ACEITE DIGITAL — ${name}`},
            NULL,
            ${String(body.userAgent || '').slice(0, 500) || null}
          ) AS data
        `
      );
      acceptanceRegistered = true;
    } catch (error) {
      // O pedido já existe e não pode ser perdido por uma falha acessória de auditoria.
      // O aceite também foi enviado dentro do payload de criação para compatibilidade.
      console.error('DOOX acceptance registration warning:', error?.message || error);
    }
  }

  let code = String(
    pedido?.codigo_doox ||
    pedido?.codigo ||
    createdCode ||
    created?.codigo_doox ||
    created?.codigoDoox ||
    created?.codigo ||
    created?.code ||
    created?.pedido?.codigo_doox ||
    created?.pedido?.codigo ||
    ''
  ).trim();
  if (!code) {
    try {
      const rows = await db`
        SELECT codigo_doox
        FROM doox_core.pedidos
        WHERE id = ${pedidoId}::uuid
        LIMIT 1
      `;
      code = String(rows?.[0]?.codigo_doox || '').trim();
    } catch (_) {}
  }
  if (!code) throw new Error('A solicitação foi registrada, mas sua identificação não pôde ser lida.');

  const trackingToken = makeTrackingToken(pedidoId);
  const baseUrl = process.env.DOOX_PUBLIC_BASE_URL || 'https://doox-omega.vercel.app';
  const trackingUrl = `${baseUrl.replace(/\/$/, '')}/?token=${encodeURIComponent(trackingToken)}`;

  return {
    ok: true,
    code,
    modality: modalityName(pedido?.modalidade || modality),
    modalityCode: pedido?.modalidade || modality,
    quantity: pedido?.quantidade || quantity,
    unitPrice: Number(pedido?.valor_unitario ?? created?.valor_unitario ?? 0),
    total: Number(pedido?.valor_total ?? created?.valor_total ?? 0),
    discount: Number(body.discount || 0) > 0 ? Number(body.discount) : 0,
    coupon: benefit?.codigo || '',
    trackingToken,
    trackingUrl,
    technicalId: pedidoId,
    pedidoId,
    id: pedidoId,
    codigoDoox: code,
    requestId: idempotencyKey,
    status: pedido?.status_operacional || 'SOLICITADO',
    paymentStatus: pedido?.status_pagamento || 'AGUARDANDO_PAGAMENTO',
    acceptanceRegistered,
  };
}

async function getTracking(req, url, body) {
  const token = String(url.searchParams.get('token') || body.token || '').trim();
  const pedidoId = verifyTrackingToken(token);

  const pedido = await callJson(
    db`SELECT doox_core.consultar_pedido(${pedidoId}::uuid) AS data`
  );

  return normalizeTracking(pedido, {
    ...pedido.pedido,
    materiais: pedido.materiais || [],
    pagamentos: pedido.pagamentos || [],
  });
}

async function informPayment(req, url, body) {
  const token = String(url.searchParams.get('token') || body.token || '').trim();
  const pedidoId = verifyTrackingToken(token);

  await callJson(
    db`
      INSERT INTO doox_core.historico (
        pedido_id,
        entidade,
        campo,
        valor_anterior,
        valor_novo,
        origem,
        observacao
      ) VALUES (
        ${pedidoId}::uuid,
        'PAGAMENTO',
        'aviso_cliente',
        NULL,
        'INFORMADO_PELO_CLIENTE',
        'O participante informou pelo acompanhamento que realizou o pagamento. O status RECEBIDO depende de conferência pela DOOX.'
      )
      RETURNING jsonb_build_object('ok', true) AS data
    `
  );

  return {
    ok: true,
    message: 'Pagamento informado. A confirmação do status depende da conferência pela DOOX.',
  };
}

async function adminAction(action, body) {
  switch (action) {
    case 'confirmarPagamento': {
      const pedidoId = body.pedidoId || body.pedido_id;
      if (!pedidoId) throw new Error('pedidoId é obrigatório.');
      const valor = Number(body.valor);
      return callJson(db`
        SELECT doox_core.confirmar_pagamento(
          ${pedidoId}::uuid,
          ${valor},
          ${body.referencia_externa || null},
          ${body.metodo || null},
          NULL
        ) AS data
      `);
    }
    case 'registrarMaterial': {
      return callJson(db`
        SELECT doox_core.registrar_material(
          ${body.pedidoId}::uuid,
          ${body.tipo_material},
          ${body.nome_original},
          ${body.mime_type},
          ${Number(body.tamanho_bytes)},
          ${body.storage_path},
          ${body.hash_arquivo || null}
        ) AS data
      `);
    }
    case 'aprovarMaterial': {
      return callJson(db`
        SELECT doox_core.aprovar_material(
          ${body.materialId}::uuid,
          ${body.aprovado === true},
          ${body.motivo || null}
        ) AS data
      `);
    }
    case 'definirMomento': {
      return callJson(db`
        SELECT doox_core.definir_momento(
          ${body.pedidoId}::uuid,
          ${body.momentoId}::uuid
        ) AS data
      `);
    }
    case 'reservarPosicoes': {
      return callJson(db`
        SELECT doox_core.reservar_posicoes(${body.pedidoId}::uuid) AS data
      `);
    }
    case 'mudarProducao': {
      return callJson(db`
        SELECT doox_core.mudar_producao(
          ${body.pedidoId}::uuid,
          ${body.status},
          ${body.observacao || null},
          NULL
        ) AS data
      `);
    }
    case 'programar': {
      return callJson(db`
        SELECT doox_core.programar_pedido(
          ${body.pedidoId}::uuid,
          ${body.data_hora}::timestamptz,
          NULL
        ) AS data
      `);
    }
    case 'veicular': {
      return callJson(db`
        SELECT doox_core.marcar_veiculado(
          ${body.pedidoId}::uuid,
          NULL
        ) AS data
      `);
    }
    case 'finalizar': {
      return callJson(db`
        SELECT doox_core.finalizar_pedido(
          ${body.pedidoId}::uuid,
          NULL,
          ${body.observacao || null}
        ) AS data
      `);
    }
    case 'cancelar': {
      return callJson(db`
        SELECT doox_core.cancelar_pedido(
          ${body.pedidoId}::uuid,
          ${body.observacao || null},
          NULL
        ) AS data
      `);
    }
    case 'dashboard': {
      const [rows] = await Promise.all([
        db`
          SELECT
            COUNT(*) FILTER (WHERE status_operacional = 'SOLICITADO') AS novos,
            COUNT(*) FILTER (WHERE status_operacional = 'EM_ANALISE') AS em_analise,
            COUNT(*) FILTER (WHERE status_pagamento = 'AGUARDANDO_PAGAMENTO') AS aguardando_pagamento,
            COUNT(*) FILTER (WHERE status_material = 'PENDENTE') AS material_pendente,
            COUNT(*) FILTER (WHERE status_operacional = 'FILA_DE_ESPERA') AS fila,
            COUNT(*) FILTER (WHERE status_producao = 'EM_PRODUCAO') AS em_producao,
            COUNT(*) FILTER (WHERE status_veiculacao = 'PROGRAMADA') AS programadas,
            COUNT(*) FILTER (WHERE status_veiculacao = 'VEICULADA') AS veiculadas,
            COALESCE(SUM(valor_total) FILTER (WHERE status_pagamento = 'RECEBIDO'),0) AS valor_recebido
          FROM doox_core.pedidos
        `,
        db`SELECT * FROM doox_core.v_pedidos_operacionais ORDER BY criado_em DESC LIMIT 100`,
        db`SELECT * FROM doox_core.v_fila_espera`,
        db`SELECT * FROM doox_core.v_disponibilidade ORDER BY episodio_numero, inicio_segundos`,
        db`SELECT * FROM doox_core.v_mapa_posicoes ORDER BY episodio_numero, momento_codigo, posicao_numero`,
      ]);

      return {
        ok: true,
        indicadores: rows[0] || {},
        pedidos: rows[1] || [],
        fila: rows[2] || [],
        disponibilidade: rows[3] || [],
        mapa: rows[4] || [],
      };
    }
    case 'listarPedidos': {
      const limit = Math.min(parsePositiveInt(body.limit, 100), 500);
      const result = await db`
        SELECT *
        FROM doox_core.v_pedidos_operacionais
        ORDER BY criado_em DESC
        LIMIT ${limit}
      `;
      return { ok: true, pedidos: result };
    }
    case 'listarFila': {
      const result = await db`SELECT * FROM doox_core.v_fila_espera`;
      return { ok: true, fila: result };
    }
    case 'listarDisponibilidade': {
      const result = await db`
        SELECT * FROM doox_core.v_disponibilidade
        ORDER BY episodio_numero, inicio_segundos
      `;
      return { ok: true, disponibilidade: result };
    }
    case 'listarMapa': {
      const result = await db`
        SELECT * FROM doox_core.v_mapa_posicoes
        ORDER BY episodio_numero, momento_codigo, posicao_numero
      `;
      return { ok: true, mapa: result };
    }
    case 'pedidoDetalhe': {
      const pedidoId = body.pedidoId || body.pedido_id;
      if (!pedidoId) throw new Error('pedidoId é obrigatório.');
      const detail = await callJson(
        db`SELECT doox_core.consultar_pedido(${pedidoId}::uuid) AS data`
      );
      let historico = [];
      try {
        historico = await db`
          SELECT *
          FROM doox_core.historico
          WHERE pedido_id = ${pedidoId}::uuid
          ORDER BY criado_em DESC
          LIMIT 100
        `;
      } catch {
        historico = [];
      }
      if (detail && typeof detail === 'object') {
        return { ok: true, detail: { ...detail, historico } };
      }
      return { ok: true, detail: { data: detail, historico } };
    }
    default:
      throw new Error(`Ação administrativa não reconhecida: ${action}`);
  }
}

function publicErrorCode(error) {
  if (error?.publicStage === 'REGISTRO_PEDIDO') {
    const raw = String(error?.message || '');
    if (/faixa|momento/i.test(raw)) return 'REG-FAIXA';
    if (/quantidade/i.test(raw)) return 'REG-QUANTIDADE';
    if (/disponibilidade|vaga/i.test(raw)) return 'REG-DISPONIBILIDADE';
    if (/modalidade/i.test(raw)) return 'REG-MODALIDADE';
    const pg = String(error?.code || '').toUpperCase();
    if (pg === '42883') return 'REG-FUNCAO';
    if (pg === '42P01' || pg === '3F000') return 'REG-ESTRUTURA';
    if (pg === '23505') return 'REG-DUPLICIDADE';
    if (pg === '23503') return 'REG-REFERENCIA';
    if (pg === '23514' || pg === '22P02') return 'REG-VALIDACAO';
    return 'REG-CORE';
  }
  if (String(error?.message || '').match(/identificador operacional|identificação não pôde ser lida/i)) return 'REG-IDENTIFICACAO';
  return 'OPERACAO';
}

function publicErrorMessage(error) {
  const raw = String(error?.message || '').trim();
  const allowed = [
    /Termos de Uso/i,
    /Regras de Participação/i,
    /Nome, WhatsApp e E-mail/i,
    /Tipo de participação inválido/i,
    /Modalidade inválida/i,
    /momento\/faixa/i,
    /faixa/i,
    /quantidade/i,
    /disponibilidade/i,
    /vagas/i,
    /preço/i,
    /valor/i,
    /Nome da empresa é obrigatório/i,
    /Pessoa física participa somente/i,
    /Apoiador Individual é exclusivo/i,
    /Termo de Participação Empresarial/i,
    /Solicitação recusada/i,
    /identificador operacional/i,
    /identificação não pôde ser lida/i,
    /Token de acompanhamento inválido/i,
    /Token de acompanhamento expirado/i,
  ];
  if (allowed.some(rx => rx.test(raw))) return raw;
  if (error?.publicStage === 'REGISTRO_PEDIDO') {
    return 'Não foi possível registrar a solicitação no sistema neste momento.';
  }
  return 'Não foi possível concluir a operação agora. Tente novamente.';
}

export default async function handler(req, res) {
  if (!['GET', 'POST'].includes(req.method)) {
    return json(res, 405, { ok: false, message: 'Método não permitido.' });
  }

  const url = new URL(req.url, `https://${req.headers.host || 'doox-omega.vercel.app'}`);
  const body = normalizeBody(req);
  const action = getAction(req, url, body);

  try {
    if (action === 'adminLogin') {
      if (req.method !== 'POST') return json(res, 405, { ok: false, message: 'adminLogin exige POST.' });
      return adminLogin(req, res, body);
    }

    if (action === 'adminLogout') {
      return adminLogout(req, res);
    }

    if (action === 'adminSession') {
      return json(res, 200, { ok: true, authenticated: verifyAdminSession(parseCookies(req).doox_admin_session) });
    }

    if (action === 'health') {
      let database = { configured: Boolean(db), reachable: null, error: dbConfigError || null };
      if (db) {
        try {
          await db`SELECT 1 AS ok`;
          database.reachable = true;
        } catch (error) {
          database.reachable = false;
          database.error = 'Falha de conexão com o banco.';
        }
      }
      const authenticated = verifyAdminSession(parseCookies(req).doox_admin_session);
      const basic = {
        ok: true,
        service: 'DOOX API',
        version: '2026.10.01-v77',
        available: database.reachable === true,
        timestamp: new Date().toISOString(),
      };
      if (!authenticated) return json(res, 200, basic);
      return json(res, 200, {
        ...basic,
        database,
        services: {
          tracking: Boolean(process.env.DOOX_TRACKING_SECRET || process.env.DOOX_ADMIN_SECRET || process.env.DOOX_ADMIN_SESSION_SECRET || RAW_DATABASE_URL),
          storage: Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY && (process.env.SUPABASE_URL || 'https://txbowobtfiiqqatqjfpd.supabase.co')),
        },
      });
    }

    if (!requireDb(res)) return;

    if (action === 'catalogo') {
      const catalogo = await callJson(db`SELECT doox_core.catalogo_publico() AS data`);
      return json(res, 200, { ok: true, catalogo });
    }

    if (action === 'simular') {
      const modality = mapModality(body.modality || body.modalidade || url.searchParams.get('modality'));
      const range = mapRange(body.range || body.faixa || url.searchParams.get('range'));
      const quantity = parsePositiveInt(
        body.quantity ?? body.quantidade ?? url.searchParams.get('quantity'),
        1
      );
      const result = await callJson(
        db`SELECT doox_core.simular(${modality}, ${range}, ${quantity}) AS data`
      );
      return json(res, 200, { ok: true, ...result });
    }

    if (action === 'registerRequest') {
      if (req.method !== 'POST') return json(res, 405, { ok: false, message: 'Método não permitido.' });
      const result = await registerRequest({
        ...body,
        userAgent: String(req.headers['user-agent'] || '').slice(0, 500),
      });
      return json(res, 200, result);
    }

    if (action === 'pedido') {
      const result = await getTracking(req, url, body);
      return json(res, 200, result);
    }

    if (action === 'informarPagamento') {
      if (req.method !== 'POST') return json(res, 405, { ok: false, message: 'informarPagamento exige POST.' });
      const result = await informPayment(req, url, body);
      return json(res, 200, result);
    }

    if (!requireAdmin(req, res)) return;
    const result = await adminAction(action, body);
    return json(res, 200, result);

  } catch (error) {
    const internalMessage = String(error?.message || 'Não foi possível concluir a operação.');
    const publicActions = new Set(['registerRequest', 'pedido', 'informarPagamento', 'simular', 'catalogo']);
    if (publicActions.has(action)) {
      const publicCode = publicErrorCode(error);
      const diagnosticId = crypto.randomBytes(4).toString('hex').toUpperCase();
      console.error(`DOOX public action ${action} [${publicCode}/${diagnosticId}]:`, internalMessage);
      return json(res, 400, { ok: false, code: publicCode, reference: diagnosticId, message: publicErrorMessage(error) });
    }
    const message = internalMessage.length > 500 ? internalMessage.slice(0, 500) : internalMessage;
    return json(res, 400, { ok: false, message });
  }
}
